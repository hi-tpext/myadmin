<?php

namespace extdemo\admin\model;

use think\Model;

class Extdemo extends Model
{
    protected $autoWriteTimestamp = 'datetime';
}
