DROP TABLE IF EXISTS `__PREFIX__agent_level`;

DROP TABLE IF EXISTS `__PREFIX__cms_banner` ;

DROP TABLE IF EXISTS `__PREFIX__cms_category` ;

DROP TABLE IF EXISTS `__PREFIX__cms_content` ;

DROP TABLE IF EXISTS `__PREFIX__cms_position` ;

DROP TABLE IF EXISTS `__PREFIX__cms_tag` ;

DROP TABLE IF EXISTS `__PREFIX__delivery_log` ;

DROP TABLE IF EXISTS `__PREFIX__member`;

DROP TABLE IF EXISTS `__PREFIX__member_account`;

DROP TABLE IF EXISTS `__PREFIX__member_address` ;

DROP TABLE IF EXISTS `__PREFIX__member_level` ;

DROP TABLE IF EXISTS `__PREFIX__member_log` ;

DROP TABLE IF EXISTS `__PREFIX__member_recharge` ;

DROP TABLE IF EXISTS `__PREFIX__shipping_area` ;

DROP TABLE IF EXISTS `__PREFIX__shipping_area_item` ;

DROP TABLE IF EXISTS `__PREFIX__shipping_com`;

DROP TABLE IF EXISTS `__PREFIX__shop_brand`;

DROP TABLE IF EXISTS `__PREFIX__shop_cart`;

DROP TABLE IF EXISTS `__PREFIX__shop_category` ;

DROP TABLE IF EXISTS `__PREFIX__shop_coupon_list` ;

DROP TABLE IF EXISTS `__PREFIX__shop_coupon_type` ;

DROP TABLE IF EXISTS `__PREFIX__shop_goods` ;

DROP TABLE IF EXISTS `__PREFIX__shop_goods_attr` ;

DROP TABLE IF EXISTS `__PREFIX__shop_goods_spec` ;

DROP TABLE IF EXISTS `__PREFIX__shop_goods_spec_price`;

DROP TABLE IF EXISTS `__PREFIX__shop_goods_spec_value` ;

DROP TABLE IF EXISTS `__PREFIX__shop_order` ;

DROP TABLE IF EXISTS `__PREFIX__shop_order_action` ;

DROP TABLE IF EXISTS `__PREFIX__shop_order_delivery`;

DROP TABLE IF EXISTS `__PREFIX__shop_order_goods` ;

DROP TABLE IF EXISTS `__PREFIX__shop_tag`;